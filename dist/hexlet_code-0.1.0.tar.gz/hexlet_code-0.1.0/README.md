### Hexlet tests and linter status:
[![Actions Status](https://github.com/poweredbyskx/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/poweredbyskx/python-project-49/actions)

<a href="https://codeclimate.com/github/poweredbyskx/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/ac1d63a599e500ad8a1d/maintainability" /></a>
<a href="https://codeclimate.com/github/poweredbyskx/python-project-49/test_coverage"><img src="https://api.codeclimate.com/v1/badges/ac1d63a599e500ad8a1d/test_coverage" /></a>
Проект "Игры разума" состоит из 5 игр с разными задачами.

суть игры, является ли число четным ответ: "да" или "нет"
<script src="https://asciinema.org/a/uLuXyYMQZ63TuDyVRsOnquEoq.js" id="asciicast-uLuXyYMQZ63TuDyVRsOnquEoq" async="true"></script>

суть игры, калькулятор решить правильно задачу с рандомным вычитанием, прибалением и умножением
<script src="https://asciinema.org/a/shpL5GPKhAbRXuDfd4zK1YmA6.js" id="asciicast-shpL5GPKhAbRXuDfd4zK1YmA6" async="true"></script>

суть игры, найти наибольший общий делитель рандомных чисел
<script src="https://asciinema.org/a/EfnO9Mbs6k1Y1xuukk7fieAZt.js" id="asciicast-EfnO9Mbs6k1Y1xuukk7fieAZt" async="true"></script>

суть игры, найти скрытое число
<script src="https://asciinema.org/a/OPyCM13NZBhUCPZZdvOf4ml8W.js" id="asciicast-OPyCM13NZBhUCPZZdvOf4ml8W" async="true"></script>

суть игры, опредилить простое число ответ "да" или "нет"
<script src="https://asciinema.org/a/dFnowluuD5y2DaCRoxYpsbN1a.js" id="asciicast-dFnowluuD5y2DaCRoxYpsbN1a" async="true"></script>
